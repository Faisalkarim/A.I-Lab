infile = open('sequences.seq')
